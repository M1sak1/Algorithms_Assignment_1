Algorithms_Assignment_1
The repo for algorithms assignment 1 by Andrew cox and Joshua corrigan.
Source code is located in ./Src
Key for Movements.
we only store if we can move right or down
0 - Both Right and Down are closed
1 - Only Right is open
2 - Only Below is open
3 - Both are open



Guide to running
Note: The Jar file and the input file must be in the same directory
console commands:
java -jar MazeGenerator.jar rowsize colsize outputname.txt    example: java -jar MazeGenerator.jar 3 3 smallmaze.txt
java -jar BFS.jar mazefile     example: java -jar BFS.jar smallmaze.txt
java -jar DFS.jar mazefile     example: java -jar DFS.jar smallmaze.txt
